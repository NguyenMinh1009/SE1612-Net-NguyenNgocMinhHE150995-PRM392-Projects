package com.example.cannongameapp;

import android.graphics.Point;

public class Line
{
    public Point start = new Point(); // start Point--(0,0) by default
    public Point end = new Point(); // end Point--(0,0) by default
} // end class Line
